package javaaula;


public class Professor {
    
    public static void main(String[] args) {
        
        String nome = "Maria";  
        String matricula = "00369";
        int codturma = 3;
        int codisciplina = 4;
 
        System.out.println("Nome : " + (nome));
        System.out.println("Matrícula: " + (matricula));
        System.out.println("CodTurma : " + (codturma));
        System.out.println("codisciplina: " + (codisciplina)); 
    }
}