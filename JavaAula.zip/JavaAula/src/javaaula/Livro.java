package javaaula;


public class Livro {
    
    public static void main(String[] args) {
    
    String autor = "Marcos";
    String titulo = "Java no netbeans";
    int ISDN = 277838;
    int quantidade= 10;
    
    System.out.println("Autor: " + autor);
    System.out.println("Titulo: " + titulo);
    System.out.println("ISDN: " + ISDN);
    System.out.println("Quantidade: " + quantidade);
    }
}