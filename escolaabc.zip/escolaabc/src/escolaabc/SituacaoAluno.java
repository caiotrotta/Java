package escolaabc;

public class SituacaoAluno {
   public static void main(String[] args) {
           float nota01 = 5;
           float nota02 = 5;
           float media = (nota01+nota02)/2;
           
       
           System.out.println("nota01 = " + nota01);
           System.out.println("nota02 = " + nota02);
           System.out.println("Média: " + (media));
           
           
           if(media>=7){
               String situacao;
               situacao = "Aprovado";
               System.out.println("Situação: " + (situacao)); 
           }else if (media>5){
               String situacao;
               situacao = "Reprovado";
               System.out.println("Situação: " + (situacao)); 
           }else{
               String situacao;
               situacao = "Recuperação";
               System.out.println("Situação: " + (situacao));
           }
          
    }
}