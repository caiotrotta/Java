package escolaabc;

import javax.swing.JOptionPane;


public class responsavel {
     public static void main(String[] args) {
         String nome;
         String cpf;
         String endereco;
         String telefone;
         
         nome = JOptionPane.showInputDialog("NOME:");
         cpf = JOptionPane.showInputDialog("CPF:");
         endereco = JOptionPane.showInputDialog("ENDEREÇO:");
         telefone = JOptionPane.showInputDialog("TELEFONE:");
         
         System.out.println("Nome: " + (nome));
         System.out.println("CPF: " + (cpf));
         System.out.println("ENDEREÇO: " + (endereco));
         System.out.println("TELEFONE: " + (telefone));
    }
}
