package escolaabc;

import javax.swing.JOptionPane;

public class Aluno {
    public static void main(String[] args) {
            String nome;
            String turma;
            String turno;
            String curso;
            String cpf ;
           
            nome = JOptionPane.showInputDialog("NOME:");
            turma = JOptionPane.showInputDialog("TURMA:");
            turno = JOptionPane.showInputDialog("TURNO:");
            curso = JOptionPane.showInputDialog("CURSO:");
            cpf = JOptionPane.showInputDialog("CPF:");
                
            System.out.println("Nome: " + (nome));
            System.out.println("Turma: " + (turma));
            System.out.println("Turno: " + (turno));
            System.out.println("Curso: " + (curso));
            System.out.println("CPF: " + (cpf));
           
    }
}