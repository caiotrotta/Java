
package interfaces;



import Dao.DaoVeiculo;
import classes.Veiculo;
import classes.Cliente;
import Dao.DaoCliente;
import java.util.List;
import javax.swing.JOptionPane;


public class FrmVeiculo extends javax.swing.JFrame {

   
    public FrmVeiculo() {
        initComponents();
        setLocationRelativeTo(null);
        preenche_combo();
    }

  Veiculo veiculo=new Veiculo();
   DaoVeiculo dao=new DaoVeiculo();
   DaoCliente daoc=new DaoCliente();
   Cliente cli=new Cliente();
   String selecionado,c;
   int codigo;
   
      
   
    
    private void limpar(){
        
        txtplaca.setText("");         
        txtmodelo.setText("");
        txtcor.setText("");      
        txtano.setText("");
       // txtcliente.setText("");  
       cbcliente.setSelectedIndex(0);
       cbmarca.setSelectedIndex(0);

        
        
    }
    
     private void passa_dados(){
     
        veiculo.setPlaca(txtplaca.getText());
        
        String marca = (String) cbmarca.getSelectedItem();
        veiculo.setMarca(marca);
        
        veiculo.setModelo(txtmodelo.getText());
        veiculo.setAno(txtano.getText());
        veiculo.setCor(txtcor.getText());  
   //     veiculo.setCodcliente(Integer.parseInt(txtcliente.getText()));
   
       cli.setNome(String.valueOf(cbcliente.getSelectedItem()));
       
       daoc.buscanome(cli);
       veiculo.setCodcliente(cli.getCodcliente());
   
 
        
    }
     
      private void mostra_dados(){
        
        txtplaca.setText(veiculo.getPlaca());
        cbmarca.setSelectedItem(veiculo.getMarca());        
        txtmodelo.setText(veiculo.getModelo());
        txtano.setText(veiculo.getAno());
        txtcor.setText(veiculo.getCor());
        //txtcliente.setText(String.valueOf(veiculo.getCodcliente()));
        
        
    }
      
       public void preenche_combo(){      
           
     
        
        List<Cliente> cli = daoc.PreencheClientes();
        
        for(Cliente cliente: cli){
            
            cbcliente.addItem( cliente.getNome());           
           
        }
        
    
     }
       
      
         
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtplaca = new javax.swing.JTextField();
        btNovo = new javax.swing.JButton();
        btEditar = new javax.swing.JButton();
        btSalvar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtano = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtcor = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtmodelo = new javax.swing.JTextField();
        cbmarca = new javax.swing.JComboBox<>();
        cbcliente = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(22, 207, 237));
        jPanel1.setFont(new java.awt.Font("GentiumAlt", 1, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Bitstream Vera Sans", 3, 24)); // NOI18N
        jLabel1.setText("Cadastro de Veículos ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(392, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(340, 340, 340))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, -1));

        jLabel2.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel2.setText("Placa");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 111, -1, 20));

        jLabel3.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel3.setText("Marca");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, -1, 20));

        txtplaca.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        txtplaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtplacaActionPerformed(evt);
            }
        });
        getContentPane().add(txtplaca, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 110, 40));

        btNovo.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btNovo.setText("Novo");
        btNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNovoActionPerformed(evt);
            }
        });
        getContentPane().add(btNovo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 70, 40));

        btEditar.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btEditar.setText("Atualizar");
        btEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditarActionPerformed(evt);
            }
        });
        getContentPane().add(btEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 100, 40));

        btSalvar.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btSalvar.setText("Salvar");
        btSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(btSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 80, 40));

        jButton1.setText(". . .");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 100, 40, 40));

        jLabel4.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel4.setText("Modelo");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, -1, -1));

        jLabel5.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel5.setText("Ano");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        txtano.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtanoMouseClicked(evt);
            }
        });
        txtano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtanoActionPerformed(evt);
            }
        });
        txtano.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtanoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtanoFocusLost(evt);
            }
        });
        getContentPane().add(txtano, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 120, 40));

        jLabel6.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel6.setText("Cor");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, -1, -1));
        getContentPane().add(txtcor, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 150, 140, 40));

        jLabel10.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel10.setText("Cliente");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, -1, 30));
        getContentPane().add(txtmodelo, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 100, 200, 40));

        cbmarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione a Marca", "Vollswagem", "fiat", "Ford", "Chevrolet", "Citroen", "Renault", "toyota", " " }));
        getContentPane().add(cbmarca, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 100, 160, 40));

        cbcliente.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Selecione cliente" }));
        getContentPane().add(cbcliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 150, 270, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtplacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtplacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtplacaActionPerformed

    private void btNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNovoActionPerformed
        limpar();
    }//GEN-LAST:event_btNovoActionPerformed

    private void btEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditarActionPerformed
      /*  cli.setCodcliente(Integer.parseInt(txtplaca.getText()));
        passa_dados();
        dao.editar(cli);
        JOptionPane.showMessageDialog(null,"Dados Alterados com Sucesso!");
        limpar();*/
    }//GEN-LAST:event_btEditarActionPerformed

    private void btSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarActionPerformed
        passa_dados();
        dao.cadastrar(veiculo);
        JOptionPane.showMessageDialog(null,"Veículo Cadastrado com Sucesso!"+ veiculo.getCodcliente());
        limpar();
    }//GEN-LAST:event_btSalvarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       /* cli.setCodcliente(Integer.parseInt(txtplaca.getText()));
        dao.buscacod(cli);
       cep.setCep(cli.getCep());
       daoc.buscacep(cep);
        mostra_dados();
        mostra_cep();*/
       

    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtanoActionPerformed
     
    }//GEN-LAST:event_txtanoActionPerformed

    private void txtanoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtanoMouseClicked
        
    }//GEN-LAST:event_txtanoMouseClicked

    private void txtanoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtanoFocusGained
 
    }//GEN-LAST:event_txtanoFocusGained

    private void txtanoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtanoFocusLost
      /*     cep.setCep(txtano.getText());
        daoc.buscacep(cep);
        mostra_cep();*/
    }//GEN-LAST:event_txtanoFocusLost

  
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmVeiculo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEditar;
    private javax.swing.JButton btNovo;
    private javax.swing.JButton btSalvar;
    private javax.swing.JComboBox<String> cbcliente;
    private javax.swing.JComboBox<String> cbmarca;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtano;
    private javax.swing.JTextField txtcor;
    private javax.swing.JTextField txtmodelo;
    private javax.swing.JTextField txtplaca;
    // End of variables declaration//GEN-END:variables
}
