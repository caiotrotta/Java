
package interfaces;

import Dao.DaoPeca;
import classes.Peca;
import javax.swing.JOptionPane;


public class Frmpeca extends javax.swing.JFrame {

    
    
    public Frmpeca() {
        initComponents();
        setLocationRelativeTo(null);
    }
    
    
    Peca pe=new Peca();
    
    DaoPeca dao=new DaoPeca();
    
    
    private void limpar(){
        
        txtcod.setText("");
        txtnome.setText("");
        txtquant.setText("");
        txtpreco.setText("");       
        
    }
    
    
    
    
    
    private void passa_dados(){
      //  pe.setIdpeca(Integer.parseInt(txtcod.getText()));
        pe.setNome(txtnome.getText());
        pe.setPreco(Double.parseDouble(txtpreco.getText()));
        pe.setQuant_estoque(Integer.parseInt(txtquant.getText()));        
        
        
    }
    
    private void mostra_dados(){
        
        txtcod.setText(String.valueOf(pe.getIdpeca()));
        txtnome.setText(pe.getNome());
        txtquant.setText(String.valueOf(pe.getQuant_estoque()));
        txtpreco.setText(String.valueOf(pe.getPreco()));      
        
        
    }
    
    
    
    
            
            

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtcod = new javax.swing.JTextField();
        txtnome = new javax.swing.JTextField();
        txtquant = new javax.swing.JTextField();
        txtpreco = new javax.swing.JTextField();
        btNovo = new javax.swing.JButton();
        btEditar = new javax.swing.JButton();
        btSalvar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(22, 207, 237));
        jPanel1.setFont(new java.awt.Font("GentiumAlt", 1, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Bitstream Vera Sans", 3, 24)); // NOI18N
        jLabel1.setText("Cadastro de Peças ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(159, 159, 159)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 80));

        jLabel2.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel2.setText("Código da Peça");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, 20));

        jLabel3.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel3.setText("Nome");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 120, -1, 20));

        jLabel4.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel4.setText("Quantidade em estoque");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, 20));

        jLabel5.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel5.setText("Preço");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 170, -1, 20));

        txtcod.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        txtcod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodActionPerformed(evt);
            }
        });
        getContentPane().add(txtcod, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 120, 40));

        txtnome.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        getContentPane().add(txtnome, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 110, 230, 40));

        txtquant.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        getContentPane().add(txtquant, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 120, 40));

        txtpreco.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        getContentPane().add(txtpreco, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 170, 80, 40));

        btNovo.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btNovo.setText("Novo");
        btNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNovoActionPerformed(evt);
            }
        });
        getContentPane().add(btNovo, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 70, 40));

        btEditar.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btEditar.setText("Atualizar");
        btEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditarActionPerformed(evt);
            }
        });
        getContentPane().add(btEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 100, 40));

        btSalvar.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btSalvar.setText("Salvar");
        btSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(btSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 80, 40));

        jButton1.setText(". . .");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, 40, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNovoActionPerformed
        limpar();
    }//GEN-LAST:event_btNovoActionPerformed

    private void txtcodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcodActionPerformed

    private void btSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarActionPerformed
        passa_dados();
       dao.cadastrar(pe);
         JOptionPane.showMessageDialog(null,"Peça Cadastrada com Sucesso!");
         limpar();
    }//GEN-LAST:event_btSalvarActionPerformed

    private void btEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditarActionPerformed
       pe.setIdpeca(Integer.parseInt(txtcod.getText()));
       passa_dados();
        dao.editar(pe);
       JOptionPane.showMessageDialog(null,"Dados Alterados com Sucesso!");
       limpar();
    }//GEN-LAST:event_btEditarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        pe.setIdpeca(Integer.parseInt(txtcod.getText()));
        dao.buscacod(pe);
        mostra_dados();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    
    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Frmpeca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Frmpeca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Frmpeca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Frmpeca.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Frmpeca().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEditar;
    private javax.swing.JButton btNovo;
    private javax.swing.JButton btSalvar;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtcod;
    private javax.swing.JTextField txtnome;
    private javax.swing.JTextField txtpreco;
    private javax.swing.JTextField txtquant;
    // End of variables declaration//GEN-END:variables
}
