
package interfaces;


import Dao.DaoCep;
import Dao.DaoCliente;
import classes.Cep;
import classes.Cliente;
import javax.swing.JOptionPane;


public class FrmCliente extends javax.swing.JFrame {

   
    public FrmCliente() {
        initComponents();
        setLocationRelativeTo(null);
    }

   Cliente cli=new Cliente();
   DaoCliente dao=new DaoCliente();
   
   DaoCep daoc=new DaoCep();
   
   Cep cep=new Cep();
   
      
   
    
    private void limpar(){
        
        txtcod.setText("");
        txtnome.setText("");
        txttelefone.setText("");
        txtrua.setText("");
        txtbairro.setText("");
        txtcidade.setText("");
        txtuf.setText("");
        txtcep.setText("");
        txtcomplemento.setText("");
        txtnum.setText("");      
        
        
    }
    
     private void passa_dados(){
     
        cli.setNome(txtnome.getText());
        cli.setTelefone(txttelefone.getText());
        cli.setCep(txtcep.getText());
        cli.setComplemento(txtcomplemento.getText());
        cli.setNumero(Integer.parseInt(txtnum.getText()));        
        
    }
     
      private void mostra_dados(){
        
        txtcod.setText(String.valueOf(cli.getCodcliente()));
        txtnome.setText(cli.getNome());
        txttelefone.setText(cli.getTelefone());
        txtnum.setText(String.valueOf(cli.getNumero()));
        txtcep.setText(cli.getCep());
        txtcomplemento.setText(cli.getComplemento());
        
        
    }
      
      private void mostra_cep(){
          txtrua.setText(cep.getRua());
          txtbairro.setText(cep.getBairro());
          txtcidade.setText(cep.getCidade());
          txtuf.setText(cep.getUf());
          
          
      }
      
      
         
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtcod = new javax.swing.JTextField();
        txtnome = new javax.swing.JTextField();
        btNovo = new javax.swing.JButton();
        btEditar = new javax.swing.JButton();
        btSalvar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        txtnum = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtcep = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtrua = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtbairro = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtcidade = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtuf = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtcomplemento = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txttelefone = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(22, 207, 237));
        jPanel1.setFont(new java.awt.Font("GentiumAlt", 1, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Bitstream Vera Sans", 3, 24)); // NOI18N
        jLabel1.setText("Cadastro de Clientes ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(396, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(340, 340, 340))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(23, 23, 23))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 980, -1));

        jLabel2.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel2.setText("Código do Cliente");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 111, -1, 20));

        jLabel3.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel3.setText("Nome");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, -1, 20));

        txtcod.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        txtcod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcodActionPerformed(evt);
            }
        });
        getContentPane().add(txtcod, new org.netbeans.lib.awtextra.AbsoluteConstraints(146, 98, 80, 40));

        txtnome.setFont(new java.awt.Font("Noto Sans", 2, 18)); // NOI18N
        getContentPane().add(txtnome, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 100, 350, 40));

        btNovo.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btNovo.setText("Novo");
        btNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNovoActionPerformed(evt);
            }
        });
        getContentPane().add(btNovo, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 70, 40));

        btEditar.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btEditar.setText("Atualizar");
        btEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditarActionPerformed(evt);
            }
        });
        getContentPane().add(btEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 270, 100, 40));

        btSalvar.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        btSalvar.setText("Salvar");
        btSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(btSalvar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 270, 80, 40));

        jButton1.setText(". . .");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 100, 40, 40));

        jLabel4.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel4.setText("Telefone");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 110, -1, -1));
        getContentPane().add(txtnum, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 150, 70, 40));

        jLabel5.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel5.setText("Cep");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));

        txtcep.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtcepMouseClicked(evt);
            }
        });
        txtcep.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcepActionPerformed(evt);
            }
        });
        txtcep.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtcepFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtcepFocusLost(evt);
            }
        });
        getContentPane().add(txtcep, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 150, 120, 40));

        jLabel6.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel6.setText("Rua");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 160, -1, -1));
        getContentPane().add(txtrua, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 150, 270, 40));

        jLabel7.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel7.setText("Bairro");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, -1));
        getContentPane().add(txtbairro, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 240, 40));

        jLabel8.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel8.setText("Cidade");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, -1, -1));

        txtcidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcidadeActionPerformed(evt);
            }
        });
        getContentPane().add(txtcidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, 280, 40));

        jLabel9.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel9.setText("Uf");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 210, -1, -1));
        getContentPane().add(txtuf, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 200, 70, 40));

        jLabel10.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel10.setText("Número");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 150, -1, 30));
        getContentPane().add(txtcomplemento, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 150, 130, 40));

        jLabel11.setFont(new java.awt.Font("URW Gothic L", 1, 14)); // NOI18N
        jLabel11.setText("complemento");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 160, -1, -1));
        getContentPane().add(txttelefone, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 100, 170, 40));

        jButton2.setText(". . .");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 100, 40, 40));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtcodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcodActionPerformed

    private void btNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNovoActionPerformed
        limpar();
    }//GEN-LAST:event_btNovoActionPerformed

    private void btEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditarActionPerformed
        cli.setCodcliente(Integer.parseInt(txtcod.getText()));
        passa_dados();
        dao.editar(cli);
        JOptionPane.showMessageDialog(null,"Dados Alterados com Sucesso!");
        limpar();
    }//GEN-LAST:event_btEditarActionPerformed

    private void btSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalvarActionPerformed
        passa_dados();
        dao.cadastrar(cli);
        JOptionPane.showMessageDialog(null,"Cliente Cadastrado com Sucesso!");
        limpar();
    }//GEN-LAST:event_btSalvarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cli.setCodcliente(Integer.parseInt(txtcod.getText()));
        dao.buscacod(cli);
       cep.setCep(cli.getCep());
       daoc.buscacep(cep);
        mostra_dados();
        mostra_cep();
       

    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtcidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcidadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcidadeActionPerformed

    private void txtcepActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcepActionPerformed
     
    }//GEN-LAST:event_txtcepActionPerformed

    private void txtcepMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtcepMouseClicked
        
    }//GEN-LAST:event_txtcepMouseClicked

    private void txtcepFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcepFocusGained
 
    }//GEN-LAST:event_txtcepFocusGained

    private void txtcepFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtcepFocusLost
           cep.setCep(txtcep.getText());
        daoc.buscacep(cep);
        mostra_cep();
    }//GEN-LAST:event_txtcepFocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         cli.setNome(txtnome.getText());
        dao.buscanome(cli);
       cep.setCep(cli.getCep());
       daoc.buscacep(cep);
        mostra_dados();
        mostra_cep();
    }//GEN-LAST:event_jButton2ActionPerformed

  
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btEditar;
    private javax.swing.JButton btNovo;
    private javax.swing.JButton btSalvar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtbairro;
    private javax.swing.JTextField txtcep;
    private javax.swing.JTextField txtcidade;
    private javax.swing.JTextField txtcod;
    private javax.swing.JTextField txtcomplemento;
    private javax.swing.JTextField txtnome;
    private javax.swing.JTextField txtnum;
    private javax.swing.JTextField txtrua;
    private javax.swing.JTextField txttelefone;
    private javax.swing.JTextField txtuf;
    // End of variables declaration//GEN-END:variables
}
