
package Dao;


import classes.Cliente;
import classes.Veiculo;
import conexao.Conexao;
import interfaces.Relatorio_Veiculos_Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class DaoVeiculo {
    
    private Connection con;
    private ResultSet rs;
    int cod;
    
    
    
    
    public DaoVeiculo(){
        
        this.con = new Conexao().getConnection();                 
        
    }
    
   public void cadastrar(Veiculo veiculo){
      try{
          
          PreparedStatement p=con.prepareStatement
                  ("insert into veiculo(placa,marca,modelo,ano,cor,codcliente)values(?,?,?,?,?,?)");
                 p.setString(1,veiculo.getPlaca());
                 p.setString(2,veiculo.getMarca());
                 p.setString(3,veiculo.getModelo());
                 p.setString(4,veiculo.getAno());
                 p.setString(5,veiculo.getCor());
                 p.setInt (6,veiculo.getCodcliente());
                
                   p.executeUpdate();
                   p.close();             
          
          
      } catch(SQLException erro) {
          
          throw new RuntimeException(erro);
          
          
      }
    }
   
   
   public void editar(Veiculo veiculo){      
        
            
            try{
        PreparedStatement p =
        con.prepareStatement("update veiculo set marca=?,"
                + "modelo=?,ano=?,cor=?,codcliente=?  where placa= '"+veiculo.getPlaca()+"';");
                 
                  p.setString(2,veiculo.getMarca());
                  p.setString(3,veiculo.getModelo());
                  p.setString(4,veiculo.getAno());
                  p.setString(5,veiculo.getCor());
                  p.setInt (6,veiculo.getCodcliente());
                  p.executeUpdate();
                  p.close();
        }
        catch(SQLException erro){
            
             throw new RuntimeException(erro);
        }
            
            
        }
    
       
    
    
    
    public void buscacod(Cliente cliente){
       try{
           
           PreparedStatement p=con.prepareStatement
        ("select * from cliente where codcliente = '"+cliente.getCodcliente()+"';");
           
           rs=p.executeQuery();
           
           if(rs.first()){
              cod=rs.getInt("codcliente");   
             
           }
           else{
               JOptionPane.showMessageDialog(null,"Cliente Não Encontrado");
               
           }
           
           
          p.close(); 
       } 
       catch(SQLException erro){
           
           throw new RuntimeException(erro);
       }
        
        
        
    }
    
    
     public void buscanomecli(Cliente cliente){
       try{
           
          
           
           PreparedStatement p=con.prepareStatement
        ("select * from cliente where nome= '"+cliente.getNome()+"';");
           
           rs=p.executeQuery();
           
           if(rs.first()){
              cod=rs.getInt("codcliente");  
              
               
           }
           else{
               JOptionPane.showMessageDialog(null,"Cliente Não Encontrado");
               
           }
           
           
          p.close(); 
       } 
       catch(SQLException erro){
           
           throw new RuntimeException(erro);
       }
        
        
        
    }
    
    
  
    
    
   
    
    public List<Veiculo> PreencheVeiculosCli(){
        try{
                   
         
            PreparedStatement p = con.prepareStatement("select * from veiculo where codcliente='"+cod+"'");
            rs = p.executeQuery();
             List<Veiculo>veiculoscli = new ArrayList<Veiculo>();
            while(rs.next()){
                
                Veiculo veicli=new Veiculo();
                veicli.setPlaca(rs.getString("placa"));
                veicli.setMarca(rs.getString("marca"));
                veicli.setModelo(rs.getString("modelo"));
                veicli.setCor(rs.getString("cor"));
                veicli.setAno(rs.getString("ano"));
                veicli.setCodcliente(rs.getInt("codcliente"));                
                veiculoscli.add(veicli);                
                
            }
            
            return veiculoscli;
            
        }
        catch(SQLException erro){
            throw new RuntimeException(erro);            
        }          
    }
       
        
        
    
    
    

    
    
    
    
}
