
package Dao;

import classes.Peca;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class DaoPeca {
    
    private Connection con;
    private ResultSet rs;
    
    
    
    
    public DaoPeca(){
        
        this.con = new Conexao().getConnection();
        
    }
    
    
    public void cadastrar(Peca peca){
      try{
          
          PreparedStatement p=con.prepareStatement
                  ("insert into peca(nome,preco,quantidade) values(?,?,?)");
                  p.setString(1,peca.getNome());
                  p.setDouble(2,peca.getPreco());
                  p.setInt(3,peca.getQuant_estoque());
                   p.executeUpdate();
                   p.close();       
          
          
          
      } catch(SQLException erro) {
          
          throw new RuntimeException(erro);
          
          
      }
    }
    
        
    public void buscacod(Peca peca){
       try{
           
           PreparedStatement p=con.prepareStatement
        ("select * from peca where codpeca = '"+peca.getIdpeca()+"';");
           
           rs=p.executeQuery();
           
           if(rs.first()){
               peca.setIdpeca(rs.getInt("codpeca"));
               peca.setNome(rs.getString("nome"));
               peca.setPreco(rs.getDouble("preco"));
               peca.setQuant_estoque(rs.getInt("quantidade"));
               
               
           }
           else{
               JOptionPane.showMessageDialog(null,"Peça Não Encontrada");
               
           }
           
           
          p.close(); 
       } 
       catch(SQLException erro){
           
           throw new RuntimeException(erro);
       }
        
        
        
    }
    
    
    public void editar(Peca peca){
        
        
            
            try{
        PreparedStatement p =
        con.prepareStatement("update peca set nome=?,preco=?,"
                + "quantidade=? where codpeca = '"+peca.getIdpeca()+"';");
        p.setString(1,peca.getNome());
        p.setDouble(2,peca.getPreco());
        p.setInt(3,peca.getQuant_estoque());
        p.executeUpdate();
        p.close();
        }
        catch(SQLException erro){
            
             throw new RuntimeException(erro);
        }
            
            
        }
    
    
    
    public List<Peca> PreenchePecas(){
        try{
            List<Peca>pecas = new ArrayList<Peca>();
            PreparedStatement p = con.prepareStatement("select * from peca");
            rs = p.executeQuery();
            
            while(rs.next()){
                
                Peca peca=new Peca();
                peca.setIdpeca(rs.getInt("codpeca"));
                peca.setNome(rs.getString("nome"));
                peca.setPreco(rs.getDouble("preco"));
                peca.setQuant_estoque(rs.getInt("quantidade"));
                pecas.add(peca);                
                
            }
            
            return pecas;
            
        }
        catch(SQLException erro){
            throw new RuntimeException(erro);            
        }          
    }
    
    
    
    
    
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     
        
    
    
    
    
    
    
    

