
package Dao;

import classes.Cep;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class DaoCep {
    
    
     private Connection con;
    private ResultSet rs;
    
    
    
    
    public DaoCep(){
        
        this.con = new Conexao().getConnection();
        
    }
    
    
    
     public void buscacep(Cep cep){
       try{           
           PreparedStatement p=con.prepareStatement
        ("select * from cep where cep = '"+cep.getCep()+"';"); 
           
           rs=p.executeQuery();    
           
           if(rs.first()){
               cep.setCep(rs.getString("cep"));
               cep.setRua(rs.getString("rua"));
               cep.setBairro(rs.getString("bairro"));
               cep.setCidade(rs.getString("cidade"));
               cep.setUf(rs.getString("uf"));              
               
           }
           else{
               JOptionPane.showMessageDialog(null,"Cep Não Encontrado");
               
           }           
           
          p.close(); 
       } 
       catch(SQLException erro){
           
           throw new RuntimeException(erro);
       }
        
        
        
    }
    
    
    
    
    
    
    
    
    
}
