


package Dao;

import classes.Cep;
import classes.Cliente;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class DaoCliente {
    
    private Connection con;
    private ResultSet rs;
    
    
    
    
    public DaoCliente(){
        
        this.con = new Conexao().getConnection();
        
    }
    
    
    public void cadastrar(Cliente cliente){
      try{
          
          PreparedStatement p=con.prepareStatement
                  ("insert into cliente(nome,cep,numero,complemento,telefone)values(?,?,?,?,?)");
                 p.setString(1,cliente.getNome());
                p.setString(2,cliente.getCep());
                  p.setInt(3,cliente.getNumero());
                  p.setString(4,cliente.getComplemento());
                  p.setString(5,cliente.getTelefone());
                   p.executeUpdate();
                   p.close();             
          
          
      } catch(SQLException erro) {
          
          throw new RuntimeException(erro);
          
          
      }
    }
    
        
    public void buscacod(Cliente cliente){
       try{           
           PreparedStatement p=con.prepareStatement
        ("select * from cliente where codcliente = '"+cliente.getCodcliente()+"';");
           
           rs=p.executeQuery();
           
           if(rs.first()){
               cliente.setCodcliente(rs.getInt("codcliente"));
               cliente.setNome(rs.getString("nome"));
               cliente.setCep(rs.getString("cep"));
               cliente.setNumero(rs.getInt("numero"));
               cliente.setComplemento(rs.getString("complemento"));
               cliente.setTelefone(rs.getString("telefone"));              
               
           }
           else{
               JOptionPane.showMessageDialog(null,"Cliente Não Encontrado");
               
           }
           
           
          p.close(); 
       } 
       catch(SQLException erro){
           
           throw new RuntimeException(erro);
       }
        
        
        
    }
    
    
    public void buscanome(Cliente cliente){
       try{           
           PreparedStatement p=con.prepareStatement
        ("select * from cliente where nome = '"+cliente.getNome()+"';");
           
           rs=p.executeQuery();
           
           if(rs.first()){
               cliente.setCodcliente(rs.getInt("codcliente"));
               cliente.setNome(rs.getString("nome"));
               cliente.setCep(rs.getString("cep"));
               cliente.setNumero(rs.getInt("numero"));
               cliente.setComplemento(rs.getString("complemento"));
               cliente.setTelefone(rs.getString("telefone"));              
               
           }
           else{
               JOptionPane.showMessageDialog(null,"Cliente Não Encontrado");
               
           }
           
           
          p.close(); 
       } 
       catch(SQLException erro){
           
           throw new RuntimeException(erro);
       }
        
        
        
    }
    
    
    public void editar(Cliente cliente){      
        
            
            try{
        PreparedStatement p =
        con.prepareStatement("update cliente set nome=?,cep=?,"
                + "numero=?,complemento=?,telefone=?  where codcliente= '"+cliente.getCodcliente()+"';");
         p.setString(1,cliente.getNome());
                p.setString(2,cliente.getCep());
                  p.setInt(3,cliente.getNumero());
                  p.setString(4,cliente.getComplemento());
                  p.setString(5,cliente.getTelefone());
                p.executeUpdate();
                p.close();
        }
        catch(SQLException erro){
            
             throw new RuntimeException(erro);
        }
            
            
        }
    
    
    
     public List<Cliente> PreencheClientes(){
        try{
            List<Cliente>clientes = new ArrayList<Cliente>();
            PreparedStatement p = con.prepareStatement("select * from cliente");
            rs = p.executeQuery();
            
            while(rs.next()){                
                Cliente cli=new Cliente();
                cli.setCodcliente(rs.getInt("codcliente"));
                cli.setNome(rs.getString("nome"));
                cli.setTelefone(rs.getString("telefone"));                
                clientes.add(cli);               
            }
            
            return clientes;
            
        }
        catch(SQLException erro){
            throw new RuntimeException(erro);            
        }          
    }
       
        
        
    
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    






    

