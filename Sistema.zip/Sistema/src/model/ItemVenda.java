package model;

public class ItemVenda {
    private int iditemvenda;
    private int codigo;
    private Venda venda;
    private Produto produto;
    private int quantidade;
    private Double valorunitario;

    public ItemVenda() {
        this.iditemvenda = 0;
        this.venda = new Venda();
        this.produto = new Produto();
        this.quantidade = 0;
        this.valorunitario = 0.0;
    }

    public ItemVenda(int codigo) {
        this.codigo = codigo;
        this.venda = new Venda();
        this.produto = new Produto();
        this.quantidade = 0;
        this.valorunitario = 0.0;
    }

    /**
     * @return the iditemvenda
     */
    public int getIditemvenda() {
        return iditemvenda;
    }

    /**
     * @param iditemvenda the iditemvenda to set
     */
    public void setIditemvenda(int iditemvenda) {
        this.iditemvenda = iditemvenda;
    }

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the venda
     */
    public Venda getVenda() {
        return venda;
    }

    /**
     * @param venda the venda to set
     */
    public void setVenda(Venda venda) {
        this.venda = venda;
    }

    /**
     * @return the produto
     */
    public Produto getProduto() {
        return produto;
    }

    /**
     * @param produto the produto to set
     */
    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the valorunitario
     */
    public Double getValorunitario() {
        return valorunitario;
    }

    /**
     * @param valorunitario the valorunitario to set
     */
    public void setValorunitario(Double valorunitario) {
        this.valorunitario = valorunitario;
    }

}
