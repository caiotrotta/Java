package utils;

import java.sql.Connection;

import java.sql.DriverManager;
import static java.sql.DriverManager.getConnection;
import static java.sql.DriverManager.getConnection;

import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Conexao {

    public Connection getConnection() {
        try {
            return DriverManager.getConnection("jdbc:mysql://localhost/controle", "root", "");
        } catch (SQLException excecao) {
            throw new RuntimeException(excecao);
        }
    }
    
    public void confirmar() throws SQLException {
        try (Connection objConnection = new Conexao().getConnection()) {
            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso! ");
        }
    }
    
}
