package dao;

import utils.Conexao;
import model.Usuario;
import java.sql.*;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Cliente;

public class UsuarioDAO {

    private Connection connection;

    PreparedStatement stmt;
    int id;
    String nome;
    String cpf;
    String email;
    String telefone;

    public UsuarioDAO() {
        this.connection = new Conexao().getConnection();
    }

    public void save(Usuario objUsuario) {
        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO usuario(nome, cpf, email, telefone) VALUES (?,?,?,?)");

            stmt.setString(1, objUsuario.getNome());
            stmt.setString(2, objUsuario.getCpf());
            stmt.setString(3, objUsuario.getEmail());
            stmt.setString(4, objUsuario.getTelefone());

            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void alterarUsuario(Usuario objUsuario) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE usuario set nome = ?, cpf = ?, email = ?, telefone = ? where id = ?");
            connection = new Conexao().getConnection();

            stmt.setString(1, objUsuario.getNome());
            stmt.setString(2, objUsuario.getCpf());
            stmt.setString(3, objUsuario.getEmail());
            stmt.setString(4, objUsuario.getTelefone());
            stmt.setInt(5, objUsuario.getId());
            stmt.execute();
            stmt.close();

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Usuário alterado com sucesso" + erro);
        }

    }

    public void saveOralterarUsuario(Usuario objUsuario) {
        if (objUsuario.getId() == 0) {
            save(objUsuario);
        } else {
            alterarUsuario(objUsuario);
        }
    }

    public ArrayList buscar(Usuario objUsuario) {
        try {
            String sql = "";
            if (!objUsuario.getNome().isEmpty()) {
                sql = "SELECT * FROM usuario WHERE nome LIKE '%" + objUsuario.getNome() + "%' ";

            } else if (!objUsuario.getCpf().isEmpty()) {
                sql = "SELECT * FROM usuario WHERE cpf LIKE '%" + objUsuario.getCpf() + "%' ";
            }
            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getString("email"),
                    rs.getString("telefone")
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }

    }

    public void deletar(Usuario objUsuario) {
        try {
            String sql;
            if (!String.valueOf(objUsuario.getId()).isEmpty()) {
                sql = "DELETE FROM usuario WHERE usuario.id = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setInt(1, objUsuario.getId());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public ArrayList listarTodos() {
        try {

            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement("SELECT * FROM usuario");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getString("email"),
                    rs.getString("telefone")
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }
    }

    public static void testarConexao() throws SQLException {
        try (Connection objConnection = new Conexao().getConnection()) {
            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso! ");
        }
    }
    
     public List<Usuario> PreencheUsuarios(){
        try{
            List<Usuario>usuarios = new ArrayList<Usuario>();
            PreparedStatement ps = connection.prepareStatement("select * from usuario");
            ResultSet rs  = ps.executeQuery();
            
            while(rs.next()){                
                Usuario usu=new Usuario();
                usu.setId(rs.getInt("ID"));
               usu.setNome(rs.getString("Nome"));
               usu.setCpf(rs.getString("Cpf"));
                usu.setEmail(rs.getString("Email")); 
                
                usu.setTelefone(rs.getString("Telefone"));                
                usuarios.add(usu);               
            }
            
            return usuarios;
            
        }
        catch(SQLException erro){
            throw new RuntimeException(erro);            
        }          
    }
         
}