package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Cliente;
import model.Produto;
import utils.Conexao;

public class ClienteDAO {
        
    private Connection connection;

    PreparedStatement stmt;
    int id;
    String nome;
    String email;
    String sexo;
    String telefone;

    public ClienteDAO() {
        this.connection = new Conexao().getConnection();
    }
    
    public void save(Cliente objCliente) {
        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO cliente(nome, email, sexo, telefone) VALUES (?,?,?,?)");

            stmt.setString(1, objCliente.getNome());
            stmt.setString(2, objCliente.getEmail());
            stmt.setString(3, objCliente.getSexo());
            stmt.setString(4, objCliente.getTelefone());


            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void alterarCliente(Cliente objCliente) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE cliente set nome = ?, email = ?, sexo = ?, telefone = ? where id = ?");
            connection = new Conexao().getConnection();

            stmt.setString(1, objCliente.getNome());
            stmt.setString(2, objCliente.getEmail());
            stmt.setString(3, objCliente.getSexo());
            stmt.setString(4, objCliente.getTelefone());
            stmt.setInt(5, objCliente.getId());
            stmt.execute();
            stmt.close();

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Cliente alterado com sucesso" + erro);
        }

    }

    public void saveOralterarCliente(Cliente objCliente) {
        if (objCliente.getId() == 0) {
            save(objCliente);
        } else {
            alterarCliente(objCliente);
        }
    }

    public ArrayList buscar(Cliente objCliente) {
        try {
            String sql = "";
            if (!objCliente.getNome().isEmpty()) {
                sql = "SELECT * FROM cliente WHERE descricao LIKE '%" + objCliente.getNome() + "%' ";

            } else if (!objCliente.getEmail().isEmpty()) {
                sql = "SELECT * FROM cliente WHERE categoria LIKE '%" + objCliente.getEmail() + "%' ";
            }
            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("sexo"),
                    rs.getString("telefone"),
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }

    }

    public ArrayList listarTodos() {
        try {

            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement("SELECT * FROM cliente");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("email"),
                    rs.getString("sexo"),
                    rs.getString("telefone")
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }
    }

    public static void testarConexao() throws SQLException {
        try (Connection objConnection = new Conexao().getConnection()) {
            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso! ");
        }
    }

    public void deletar(Cliente objCliente) {
        try {
            String sql;
            if (!String.valueOf(objCliente.getId()).isEmpty()) {
                sql = "DELETE FROM cliente WHERE cliente.id = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setInt(1, objCliente.getId());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
    
      public List<Cliente> PreencheClientes(){
        try{
            List<Cliente>clientes = new ArrayList<Cliente>();
            PreparedStatement ps = connection.prepareStatement("select * from cliente");
            ResultSet rs  = ps.executeQuery();
            
            while(rs.next()){                
                Cliente cli=new Cliente();
                cli.setId(rs.getInt("ID"));
                cli.setNome(rs.getString("Nome"));
                cli.setEmail(rs.getString("Email")); 
                cli.setSexo(rs.getString("Sexo")); 
                cli.setTelefone(rs.getString("Telefone"));                
                clientes.add(cli);               
            }
            
            return clientes;
            
        }
        catch(SQLException erro){
            throw new RuntimeException(erro);            
        }          
    }
         
   public Cliente recuperar(int id) throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM CLIENTE WHERE id=?";
        PreparedStatement ps = c.getConnection().prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();

        Cliente cli=new Cliente();
        if (rs.next()) {
              cli.setId(rs.getInt("ID"));
                cli.setNome(rs.getString("Nome"));
                cli.setEmail(rs.getString("Email")); 
                cli.setSexo(rs.getString("Sexo")); 
                cli.setTelefone(rs.getString("Telefone"));  
         
        }

        return cli;
    }
}    

