package dao;

import gui.IDAO;
import java.sql.Connection;
import model.ItemVenda;
import dao.ClienteDAO;
import dao.ProdutoDAO;
import model.Venda;
import utils.Situacao;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import utils.Conexao;


public class VendaDAO implements IDAO<Venda> {
 private Connection connection;

    PreparedStatement stmt;
    int id, codigo;
    String nome;
    Date datavenda;
    Float valortotal;
    String situacao;

    public VendaDAO() {
        this.connection = new Conexao().getConnection();
    }
    @Override
    public void inserir(Venda venda) throws Exception {
      
         try {
            
        String sql = "INSERT INTO venda(id, datavenda, valortotal, situacao) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmt.setInt(1, venda.getCliente().getId());
        stmt.setDate(2, new Date(venda.getDatavenda().getTime()));
        stmt.setDouble(3, venda.getValortotal());
        stmt.setInt(4, venda.getSituacao().getId());
        stmt.execute();

        ResultSet rs = stmt.getGeneratedKeys();
        rs.next();
        int codigo = rs.getInt(1);

        for (ItemVenda iv : venda.getItens()) {
            sql = "INSERT INTO itemvenda (CODIGOPRODUTO, CODIGOVENDA, QUANTIDADE, VALORUNITARIO) VALUES (?, ?, ?, ?)";
            stmt= connection.prepareStatement(sql);
            stmt.setInt(1, iv.getProduto().getIdproduto());
            stmt.setInt(2, codigo);
            stmt.setInt(3, iv.getQuantidade());
            stmt.setDouble(4, iv.getValorunitario());
            stmt.execute();

            if (venda.getSituacao() == Situacao.FINALIZADA) {
                ProdutoDAO produtoDAO = new ProdutoDAO();
                
            }
        } } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }

  
    public void alterar(Venda venda) throws Exception {
        Conexao c = new Conexao();
        String sql = "UPDATE venda SET id=?, datavenda=?, valortotal=?, situacao=? WHERE codigo=?";
       stmt = connection.prepareStatement(sql);
      
       stmt.setInt(1, venda.getCliente().getId());
        stmt.setDate(2, new Date(venda.getDatavenda().getTime()));
        stmt.setDouble(3, venda.getValortotal());
        stmt.setInt(4, venda.getSituacao().getId());
        stmt.setInt(5, venda.getCodigo());
        stmt.execute();

        for (ItemVenda iv : venda.getItensRemover()) {
            sql = "DELETE FROM venda WHERE codigo=?";
            stmt = connection.prepareStatement(sql);
          
            stmt.setInt(1, iv.getCodigo());
            stmt.execute();
        }

        for (ItemVenda iv : venda.getItens()) {
            if (iv.getCodigo() == 0) {
                sql = "INSERT INTO venda (idproduto, codigo, quantidade, valorunitario) VALUES (?, ?, ?, ?)";
                 stmt = connection.prepareStatement(sql);
               
                stmt.setInt(1, iv.getProduto().getIdproduto());
               stmt.setInt(2, iv.getVenda().getCodigo());
                stmt.setInt(3, iv.getQuantidade());
                stmt.setDouble(4, iv.getValorunitario());
                stmt.execute();
            } else {
                sql = "UPDATE venda SET idproduto=?, CODIGOVENDA=?, QUANTIDADE=?, VALORUNITARIO=? WHERE CODIGO=?";
                  stmt = connection.prepareStatement(sql);
                
                stmt.setInt(1, iv.getProduto().getIdproduto());
                stmt.setInt(2, iv.getVenda().getCodigo());
                stmt.setInt(3, iv.getQuantidade());
                stmt.setDouble(4, iv.getValorunitario());
                stmt.setInt(5, iv.getCodigo());
                stmt.execute();
            }

            if (venda.getSituacao() == Situacao.FINALIZADA) {
                ProdutoDAO produtoDAO = new ProdutoDAO();
               
            }
        }

         c.confirmar();
    }

    @Override
    public void excluir(Venda venda) throws Exception {
        Conexao c = new Conexao();
        String sql = "UPDATE venda SET id=?, datavenda=?, valortotal=?, situacao=? WHERE codigo=?";
        
        stmt = connection.prepareStatement(sql);
        stmt.setInt(1, venda.getCliente().getId());
        stmt.setDate(2, new Date(venda.getDatavenda().getTime()));
        stmt.setDouble(3, venda.getValortotal());
        stmt.setInt(4, Situacao.CANCELADA.getId());
        stmt.setInt(5, venda.getCodigo());
        stmt.execute();
       
    }

    @Override
    public ArrayList<Venda> listarTodos() throws Exception {
        Conexao c = new Conexao();
        ClienteDAO clienteDAO = new ClienteDAO();
        ProdutoDAO produtoDAO = new ProdutoDAO();

        String sql = "SELECT * FROM venda ORDER BY datavenda DESC";
         stmt = connection.prepareStatement(sql);
        
        ResultSet rs = stmt.executeQuery();

        ArrayList listaVendas = new ArrayList();
        while (rs.next()) {
            Venda venda = new Venda();
            venda.setCodigo(rs.getInt("Codigo"));
            venda.setCliente(clienteDAO.recuperar(rs.getInt("Id")));
            venda.setDatavenda(rs.getDate("Datavenda"));
            venda.setSituacao(rs.getInt("Situacao"));

            String sqlItem = "SELECT * FROM venda WHERE codigo=?";
             stmt = connection.prepareStatement(sqlItem);
           
           stmt.setInt(1, venda.getCodigo());
            ResultSet rsItem = stmt.executeQuery();

            while (rsItem.next()) {
                ItemVenda iv = new ItemVenda();
                iv.setCodigo(rsItem.getInt("Codigo"));
                iv.setProduto(produtoDAO.recuperar(rsItem.getInt("Idproduto")));
                iv.setVenda(venda);
                iv.setQuantidade(rsItem.getInt("Quantidade"));
                iv.setValorunitario(rsItem.getDouble("Valorunitario"));
                venda.addItem(iv);
            }

            listaVendas.add(venda);
        }

        return listaVendas;
    }

    @Override
    public Venda recuperar(int codigo) throws Exception {
        Conexao c = new Conexao();
        ClienteDAO clienteDAO = new ClienteDAO();
        ProdutoDAO produtoDAO = new ProdutoDAO();

        String sql = "SELECT * FROM venda ORDER BY datavenda DESC";
          stmt = connection.prepareStatement(sql);
      
        ResultSet rs = stmt.executeQuery();

        Venda venda = new Venda();
        if (rs.next()) {
            venda.setCodigo(rs.getInt("Codigo"));
            venda.setCliente(clienteDAO.recuperar(rs.getInt("Id")));
          
            venda.setDatavenda(rs.getDate("Datavenda"));
          
            venda.setSituacao(rs.getInt("Situacao"));

            String sqlItem = "SELECT * FROM venda WHERE codigo=?";
             stmt = connection.prepareStatement(sqlItem);
         
            stmt.setInt(1, venda.getCodigo());
            ResultSet rsItem = stmt.executeQuery();

            while (rsItem.next()) {
                ItemVenda iv = new ItemVenda();
                iv.setCodigo(rsItem.getInt("Codigo"));
                iv.setProduto(produtoDAO.recuperar(rsItem.getInt("Idproduto")));
                iv.setVenda(venda);
                iv.setQuantidade(rsItem.getInt("Quantidade"));
                iv.setValorunitario(rsItem.getDouble("Valorunitario"));
                venda.addItem(iv);
            }
        }

        return venda;
    }
}
