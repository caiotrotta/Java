package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Produto;
import utils.Conexao;

public class ProdutoDAO {
        
    private Connection connection;

    PreparedStatement stmt;
    int idproduto;
    String descricao;
    String categoria;
    float preco;
    private int qtd;
    float valor;

    public ProdutoDAO() {
        this.connection = new Conexao().getConnection();
    }
    
    public void save(Produto objProduto) {
        try {
            PreparedStatement stmt = connection.prepareStatement("INSERT INTO produto(descricao, categoria, preco, qtd, valor) VALUES (?,?,?,?,?)");

            stmt.setString(1, objProduto.getDescricao());
            stmt.setString(2, objProduto.getCategoria());
            stmt.setFloat(3, objProduto.getPreco());
            stmt.setInt(4, objProduto.getQtd());
            stmt.setFloat(5, objProduto.getValor());

            stmt.execute();
            stmt.close();
            JOptionPane.showMessageDialog(null, "Produto cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void alterarProduto(Produto objProduto) {
        try {
            PreparedStatement stmt = connection.prepareStatement("UPDATE produto set descricao = ?, categoria = ?, preco = ?, qtd = ?, valor = ? where idproduto = ?");
            connection = new Conexao().getConnection();

            stmt.setString(1, objProduto.getDescricao());
            stmt.setString(2, objProduto.getCategoria());
            stmt.setFloat(3, objProduto.getPreco());
            stmt.setInt(4, objProduto.getQtd());
            stmt.setFloat(5, objProduto.getValor());
            stmt.setInt(6, objProduto.getIdproduto());
            
            stmt.execute();
            stmt.close();

        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Produto alterado com sucesso" + erro);
        }

    }

    public void saveOralterarUsuario(Produto objProduto) {
        if (objProduto.getIdproduto() == 0) {
            save(objProduto);
        } else {
            alterarProduto(objProduto);
        }
    }

    public ArrayList buscar(Produto objProduto) {
        try {
            String sql = "";
            if (!objProduto.getDescricao().isEmpty()) {
                sql = "SELECT * FROM produto WHERE descricao LIKE '%" + objProduto.getDescricao() + "%' ";

            } else if (!objProduto.getCategoria().isEmpty()) {
                sql = "SELECT * FROM produto WHERE categoria LIKE '%" + objProduto.getCategoria() + "%' ";
            }
            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("idproduto"),
                    rs.getString("descricao"),
                    rs.getString("categoria"),
                    rs.getFloat("preco"),
                    rs.getInt("qtd"),
                    rs.getFloat("valor")
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }

    }

    public void deletar(Produto objProduto) {
        try {
            String sql;
            if (!String.valueOf(objProduto.getIdproduto()).isEmpty()) {
                sql = "DELETE FROM produto WHERE produto.idproduto = ?";
                PreparedStatement stmt = connection.prepareStatement(sql);

                stmt.setInt(1, objProduto.getIdproduto());
                stmt.execute();
                stmt.close();

            }
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public ArrayList listarTodos() {
        try {

            ArrayList dado = new ArrayList();

            PreparedStatement ps = connection.prepareStatement("SELECT * FROM produto");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                dado.add(new Object[]{
                    rs.getInt("idproduto"),
                    rs.getString("descricao"),
                    rs.getString("categoria"),
                    rs.getFloat("preco"),
                    rs.getInt("qtd"),
                    rs.getFloat("valor")
                });

            }
            ps.close();
            rs.close();
            connection.close();

            return dado;
        } catch (SQLException e) {
            e.getMessage();
            JOptionPane.showMessageDialog(null, "Erro preencher o ArrayList");
            return null;
        }
    }

    public static void testarConexao() throws SQLException {
        try (Connection objConnection = new Conexao().getConnection()) {
            JOptionPane.showMessageDialog(null, "Conexão realizada com sucesso! ");
        }
    }
    
     public List<Produto> PreencheProdutos(){
        try{
            List<Produto>produtos = new ArrayList<Produto>();
            PreparedStatement ps = connection.prepareStatement("select * from produto");
            ResultSet rs  = ps.executeQuery();
            
            while(rs.next()){                
                Produto prod=new Produto();
                prod.setIdproduto(rs.getInt("Idproduto"));
                prod.setDescricao(rs.getString("Descricao"));
                prod.setCategoria(rs.getString("Categoria")); 
                prod.setPreco(rs.getFloat("Preco")); 
                prod.setQtd(rs.getInt("Qtd"));  
                prod.setValor(rs.getFloat("Valor"));
                produtos.add(prod);               
            }
            
            return produtos;
            
        }
        catch(SQLException erro){
            throw new RuntimeException(erro);            
        }          
    }

  public void entradaEstoque(Conexao c, int codigo, int quantidade) throws Exception {
        String sql = "UPDATE PRODUTO SET qtd = QUANTIDADEESTOQUE  + ? WHERE idproduto=?";
        PreparedStatement ps = c.getConnection().prepareStatement(sql);
        ps.setInt(1, qtd);
        ps.setInt(2, idproduto);
        ps.execute();
    }

    public void saidaEstoque(Conexao c, int codigo, int quantidade) throws Exception {
        String sql = "UPDATE PRODUTO SET Qtd= QUANTIDADEESTOQUE  - ? WHERE idproduto=?";
        PreparedStatement ps = c.getConnection().prepareStatement(sql);
        ps.setInt(1, qtd);
        ps.setInt(2, idproduto);
        ps.execute();
    }
    public Produto recuperar(int codigo) throws Exception {
        Conexao c = new Conexao();
        String sql = "SELECT * FROM TBPRODUTO WHERE idproduto=?";
        PreparedStatement ps = c.getConnection().prepareStatement(sql);
        ps.setInt(1, idproduto);
        ResultSet rs = ps.executeQuery();

        Produto produto = new Produto();
        if (rs.next()) {
            produto.setIdproduto(rs.getInt("Idproduto"));
            produto.setDescricao(rs.getString("Descricao"));
            produto.setPreco(rs.getFloat("Preco"));
            produto.setQtd(rs.getInt("Qtd"));
            produto.setValor(rs.getFloat("Valor"));
        }

        return produto;
    }
}