package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Produto;
import utils.Conexao;
public class ProdutoDao {
     private Connection connection = Conexao.getConexao();

    public void save(Produto produto) {
        try {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO produto (descricao, categoria, preco, qtd, valor) VALUES (?,?,?,?,?)");
            ps.setString(1, produto.getDescricao());
            ps.setString(2, produto.getCategoria());
            ps.setFloat(3, produto.getPreco());
            ps.setInt(4, produto.getQtd());
            ps.setFloat(5, produto.getValor());
           
          
            ps.execute();
            JOptionPane.showMessageDialog(null, "Produto cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
    public void save2(Produto produto){
        if (produto.getIdproduto() == 0) {
            save(produto);
        } 
    
}}