package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Cliente;
import utils.Conexao;


public class ClienteDao {
           private Connection connection = Conexao.getConexao();

    public void save(Cliente cliente) {
        try {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO cliente (nome, email, sexo, telefone) VALUES (?,?,?,?)");
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getEmail());
            ps.setString(3, cliente.getSexo());
            ps.setString(4, cliente.getTelefone());
          
            ps.execute();
            JOptionPane.showMessageDialog(null, "Cliente cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ClienteDao.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
    
    public void save2(Cliente cliente){
        if (cliente.getId() == 0) {
            save(cliente);
            } 
        }   
    }