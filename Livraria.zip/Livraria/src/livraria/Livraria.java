/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package livraria;

public class Livraria {
    public static void main(String[] args) {  
    
  String autor = "Marcos";  
  String titulo = "Java no netbeans";
  int ISDN = 277838;
  int quantidade= 10;
 
  System.out.println("Autor = " + (autor));
  System.out.println("Título: " + titulo);
  System.out.println("ISDN = " + (ISDN));
  System.out.println("Quantidade: " + quantidade); 
    }
}
