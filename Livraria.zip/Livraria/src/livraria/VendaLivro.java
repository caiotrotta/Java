/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package livraria;

/**
 *
 * @author 42labinfo
 */
    public class VendaLivro {
     public static void main(String[] args) {
    String CNPJ = "1288488";
    String NomeLivro = "joao e o pe de feijao";
    int ISDN = 1223;
    int Qtd = 200;
    float Preco = 40;
            
    System.out.println("CNPJ: " + (CNPJ));
    System.out.println("Nome do Livro: " + (NomeLivro));
    System.out.println("ISDN: " + (ISDN));
    System.out.println("Quant: " + (Qtd));
    System.out.println("Preço: " + (Preco));
    }
}
