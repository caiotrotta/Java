package livraria;

import java.util.Scanner;

public class CadastroTeste {
        public static void main(String[] args) {
        
        Scanner Entrada = new Scanner (System.in);
        CadastroTeste CAD = new CadastroTeste();
        
        System.out.println("Cadastrando Livro");
        
    }
}